#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int fd[2];
    pipe(fd); // to use between child and grandchild

    int fd2[2];     //to use between grandchild and parent
    pipe(fd2);

    printf("I’m SHELL process, with PID: %d - Main command is: man grep | grep -A 2 -e '-A' > output.txt \n", getpid());

    int rc = fork();
    if (rc < 0)
    {
        fprintf(stderr, "fork failed\n");
        exit(1);
    }
    else if (rc == 0)
    { // child process - MAN
        printf("I’m MAN process, with PID: %d - My command is: man grep\n", getpid());
        int rc2 = fork();
        if (rc2 < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc2 == 0)
        { // grandchild process- GREP
            close(fd[1]);
            close(fd2[0]);
            printf("I’m GREP process, with PID: %d - My command is: grep -A 2 -e '-A'> output.txt\n", getpid());
            dup2(fd[0], STDIN_FILENO);
            dup2(fd2[1], STDOUT_FILENO);
            
            char *myargs[5];
            myargs[0] = strdup("grep");
            myargs[1] = strdup("-A 2");
            myargs[2] = strdup("-e");
            myargs[3] = strdup("-A");
            myargs[4] = NULL;
            execvp(myargs[0], myargs);

            
            
        }
        else
        {
            // child process - MAN
            close(fd[0]);
            close(fd2[0]); // fd2 is used for communication between grandchild (GREP) and parent(SHELL), so child does not use it 
            close(fd2[1]);
            dup2(fd[1], STDOUT_FILENO);
            char *myargs[3];
            myargs[0] = strdup("man");
            myargs[1] = strdup("grep");
            myargs[2] = NULL;
            execvp(myargs[0], myargs);
           
        }
    }
    else
    {
        close(fd[0]); // fd is used for communication between child (MAN) and grandchild(GREP), so parent does not use it 
        close(fd[1]);
        close(fd2[1]);

        dup2(fd2[0], STDIN_FILENO);
        int rc3 = fork();
         if (rc3 < 0)
        {
            fprintf(stderr, "fork failed\n");
            exit(1);
        }
        else if (rc3 == 0) //process to write to the output.txt file
        {
            int file = open("output.txt", O_CREAT  | O_WRONLY, 0666);
            dup2(file, STDOUT_FILENO);
            char* myargs[2]; 
            myargs[0] = strdup("cat");
            myargs[1] = NULL;
            execvp(myargs[0], myargs);
            close(file);
        }
        
        else{
            wait(NULL);
            printf("I’m SHELL process, with PID: %d - execution is completed, you can find the results in output.txt\n", getpid());
        }
    }
    return 0;
}

// parent process
/*close(fd[1]);
close(fd[0]);

char buf[1000];
while(read(fd[0], buf, 1000)) {
    printf("Parent recieved message: %s\n", buf);
}
char* msg = "Parent sending message!";

write(fd2[1], msg, strlen(msg));

wait(NULL);
wait(NULL);
printf("parent terminates\n");*/

// grandchild process
/*close(fd[0]);
close(fd[1]);
close(fd2[1]);
char buf[1000];
while(read(fd2[0], buf, 1000)) {
    printf("Grandchild recieved message: %s\n", buf);
}
printf("grandchild terminates\n");*/
/*
close(fd[0]);
close(fd2[0]);
close(fd2[1]);
*/


//grandchild
/*char buf[1000];
while(read(fd[0], buf, 1000)) {
printf("%s", buf);
}*/
/*dup2(file, STDOUT_FILENO);*/

//child
/*write(fd[1], msgC, strlen(msgC));
close(fd[1]);*/
/*wait(NULL);
printf("exiting child\n");*/